from zmorpho.core import ZoranMorphogenese

zm = ZoranMorphogenese()
print(zm.croissance("glyphe_demo"))
print(zm.mutation("glyphe_demo", "duplication"))
