class ZoranMorphogenese:
    def __init__(self):
        self.glyphes = []
    def croissance(self, glyphe):
        self.glyphes.append(glyphe)
        return f"Glyphe ajouté : {glyphe}"
    def mutation(self, glyphe, type_mutation):
        return f"Mutation {type_mutation} appliquée à {glyphe}"
