from zmorpho.core import ZoranMorphogenese

def test_croissance():
    zm = ZoranMorphogenese()
    res = zm.croissance("glyphe1")
    assert "glyphe1" in zm.glyphes and "ajouté" in res
